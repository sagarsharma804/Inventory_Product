﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inventory.Entities
{
    public class Product
    {
      

        public int ProductID {get;set; }
        public string ProductName { get; set; }
        public string ProductType { get; set; }
        //shift it in poduct order details
        public int ProductQuantity { get; set; }
        public int ProductPrice { get; set; }
        //Calculating the amount for all the product of same type.
        private double productAmount;
        public double ProductAmount()
        {
            productAmount = ProductPrice * ProductQuantity;
            return productAmount;
        }

       
    }
}