﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.Common;
using Inventory.Entities;
using Inventory.Exceptions;

namespace Inventory.DataAccessLayer
{
    public class ProductDAL
    {
        public static List<Product> ProductList = new List<Product>();

        public bool AddProductDAL(Product newProduct)
        {
            bool ProductDALAdded = false;
            try
            {
                ProductList.Add(newProduct);
                ProductDALAdded = true;
            }
            catch (SystemException ex)
            {
                throw new ProductException(ex.Message);
            }
            return ProductDALAdded;
        }
       

        public List<Product> GetAllProductDAL() 
        {
                return ProductList;
        }
            public List<Product> GetProductByNameDAL(string ProductName)
            {
                List<Product> searchProduct = new List<Product>();
                try
                {
                    foreach (Product item in ProductList)
                    {
                        if (item.ProductName == ProductName)
                        {
                            searchProduct.Add(item);
                        }
                    }
                }
                catch (SystemException ex)
                {
                    throw new ProductException(ex.Message);
                }
                return searchProduct;
            }

            public bool UpdateProductDAL(Product updateProduct)
            {
                bool ProductUpdated = false;
                try
                {
                    for (int i = 0; i < ProductList.Count; i++)
                    {
                        if (ProductList[i].ProductName == updateProduct.ProductName)
                        {
                        updateProduct.ProductPrice= ProductList[i].ProductPrice;
                        updateProduct.ProductQuantity = ProductList[i].ProductQuantity;

                            ProductUpdated = true;
                        }
                    }
                }
                catch (SystemException ex)
                {
                    throw new ProductException(ex.Message);
                }
                return ProductUpdated;

            }

            public bool DeleteProductDAL(int deleteProductID)
            {
                bool productDeleted = false;
                try
                {
                    Product deleteProduct = null;
                    foreach (Product item in ProductList)
                    {
                        if (item.ProductID == deleteProductID)
                        {
                            deleteProduct = item;
                        }
                    }

                    if (deleteProduct != null)
                    {
                        ProductList.Remove(deleteProduct);
                        productDeleted = true;
                    }
                }
                catch (DbException ex)
                {
                    throw new ProductException(ex.Message);
                }
                return productDeleted;




            }

        }

}
}
