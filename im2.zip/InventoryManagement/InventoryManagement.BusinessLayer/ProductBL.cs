﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Inventory.Entities;
using Inventory.Exceptions;
using Inventory.DataAccessLayer;

namespace InventoryManagement.BusinessLayer
{
    public class ProductBL
    {
        private static bool ValidateProduct(Product product)
        {
            StringBuilder sb = new StringBuilder();
            bool validProduct = true;
            if (product.ProductID <= 0)
            {
                validProduct = false;
                sb.Append(Environment.NewLine + "Invalid Product ID");

            }
            if (product.ProductName == string.Empty)
            {
                validProduct = false;
                sb.Append(Environment.NewLine + "Product Name Required");

            }
            if (product.ProductQuantity <= 0)
            {
                validProduct = false;
                sb.Append(Environment.NewLine + "Quantity can not be 0");
            }
            if (validProduct == false)
                throw new ProductException(sb.ToString());
            return validProduct;
        }
        public static bool AddProductBL(Product newProduct)
        {
            bool ProductAdded = false;
            try
            {
                if (ValidateProduct(newProduct))
                {
                    ProductBL ProductBL = new ProductBL();
                    ProductAdded = ProductBL.AddProductBL(newProduct);
                }
            }
            catch (ProductException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return ProductAdded;
        }
        public static List<Product> GetAllProductsBL()
        {
            List<Product> ProductList = null;
            try
            {
                ProductDAL ProductDAL = new ProductDAL();
                ProductList = ProductDAL.GetAllProductsDAL();
            }
            catch (ProductException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return ProductList;
        }
        public static Product SearchProductBL(int searchProductName)
        {
            Product searchProduct = null;
            try
            {
                ProductDAL ProductDAL = new ProductDAL();
                searchProduct = ProductDAL.SearchProduct(searchProductName);
            }
            catch (ProductException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchProduct;

        }
        public static bool UpdateProductBL(Product updateProduct)
        {
            bool ProductUpdated = false;
            try
            {
                if (ValidateProduct(updateProduct))
                {
                    ProductDAL ProductDAL = new ProductDAL();
                    ProductUpdated = ProductDAL.UpdateProductDAL(updateProduct);
                }
            }
            catch (ProductException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return ProductUpdated;
        }

        public static bool DeleteProductBL(int deleteProductID)
        {
            bool ProductDeleted = false;
            try
            {
                if (deleteProductID > 0)
                {
                    ProductDAL ProductDAL = new ProductDAL();
                    ProductDeleted = ProductDAL.DeleteProductDAL(deleteProductID);
                }
                else
                {
                    throw new ProductException("Invalid Product ID");
                }
            }
            catch (ProductException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return ProductDeleted;
        }
    }
    

}
