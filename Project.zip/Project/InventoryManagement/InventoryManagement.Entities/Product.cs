﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inventory.Entities
{
    public class Product
    {
        private int _ProductID;

        public int ProductID
        {
            get { return _ProductID; }
            set { _ProductID = value; }
        }
        private string _ProductName;

        public string ProductName
        {
            get { return _ProductName; }
            set { _ProductName = value; }
        }

        private string _ProductType;

        public string ProductType
        {
            get { return _ProductType; }
            set { _ProductType = value; }
        }

        private int _ProductQuantity;
        public int ProductQuantity
        {
            get { return _ProductQuantity; }
            set { _ProductQuantity = value; }
        }

        private int _Productprice;
        public int Productprice
        {
            get { return _Productprice; }
            set { _Productprice = value; }
        }

        private double _ProductAmount;
        public double ProductAmount()
        {
            _ProductAmount = Productprice * ProductQuantity;
            return _ProductAmount;
        }

        public Product()
        {
            _ProductID = 0;
            _ProductName = string.Empty;
            _ProductType = string.Empty;
            _ProductQuantity = 0;
            _Productprice = 0;

        }
    }
}