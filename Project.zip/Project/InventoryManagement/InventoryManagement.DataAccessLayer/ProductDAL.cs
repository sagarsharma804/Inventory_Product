﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.Common;
using Inventory.Entities;
using Inventory.Exceptions;

namespace Inventory.DataAccessLayer
{
    public class ProductDAL
    {
        public static List<ProductDAL> ProductList = new List<ProductDAL>();

        public bool AddProductDAL(ProductDAL newProduct)
        {
            bool ProductDALAdded = false;
            try
            {
                ProductList.Add(newProduct);
                ProductDALAdded = true;
            }
            catch (SystemException ex)
            {
                throw new ProductException(ex.Message);
            }
            return ProductDALAdded;

        }

        public List<Product> GetAllProductDAL = new List<Product>()
        {
            return ProductList ;
    }

    public List<Product> GetProductByNameDAL(string ProductName)
    {
        List<Product> searchProduct = new List<Product>();
        try
        {
            foreach (Product item in ProductList)
            {
                if (item.ProductName == ProductName)
                {
                    searchProduct.Add(item);
                }
            }
        }
        catch (SystemException ex)
        {
            throw new ProductException(ex.Message);
        }
        return searchProduct;
    }

    public bool UpdateProductDAL(ProductDAL updateProduct)
    {
        bool ProductUpdated = false;
        try
        {
            for (int i = 0; i < ProductList.Count; i++)
            {
                if (ProductList[i].GuestID == updateProduct.GuestID)
                {
                    updateGuest.GuestName = guestList[i].GuestName;
                    updateGuest.GuestContactNumber = guestList[i].GuestContactNumber;
                    guestUpdated = true;
                }
            }
        }
        catch (SystemException ex)
        {
            throw new ProductException(ex.Message);
        }
        return guestUpdated;

    }

    public bool DeleteGuestDAL(int deleteGuestID)
    {
        bool guestDeleted = false;
        try
        {
            Product deleteGuest = null;
            foreach (Product item in guestList)
            {
                if (item.GuestID == deleteGuestID)
                {
                    deleteGuest = item;
                }
            }

            if (deleteGuest != null)
            {
                guestList.Remove(deleteGuest);
                guestDeleted = true;
            }
        }
        catch (DbException ex)
        {
            throw new GuestPhoneBookException(ex.Message);
        }
        return guestDeleted;

    }

}
}
