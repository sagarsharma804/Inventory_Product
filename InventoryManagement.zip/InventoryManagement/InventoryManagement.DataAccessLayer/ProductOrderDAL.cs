﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Common;
using System.Threading.Tasks;

namespace InventoryManagement.DataAccessLayer
{
    class ProductOrderDAL
    {
         public static List<ProductOrder> ProductOrderList = new List<ProductOrder>();

        public bool AddProductOrder(ProductOrder newProductOrder)
        {
            bool ProductDALAdded = false;
            try
            {
                ProductOrderList.Add(newProductOrder);
                ProductDALAdded = true;
            }
            catch (SystemException ex)
            {
                throw new ProductOrderException(ex.Message);
            }
            return ProductDALAdded;

       

        List<ProductOrder> GetAllProductOrderDAL() 
        {
            return ProductOrder.ProductOrderList;
        }
            List<Product> GetProductByNameDAL(string ProductName)
            {
                List<Product> searchProduct = new List<Product>();
                try
                {
                    foreach (Product item in ProductList)
                    {
                        if (item.ProductName == ProductName)
                        {
                            searchProduct.Add(item);
                        }
                    }
                }
                catch (SystemException ex)
                {
                    throw new ProductException(ex.Message);
                }
                return searchProduct;
            }

            bool UpdateProductDAL(ProductDAL updateProduct)
            {
                bool ProductUpdated = false;
                try
                {
                    for (int i = 0; i < ProductList.Count; i++)
                    {
                        if (ProductList[i].ProductID == updateProduct.ProductID)
                        {
                            updateProduct.ProductName = ProductList[i].ProductName;
                            ProductUpdated = true;
                        }
                    }
                }
                catch (SystemException ex)
                {
                    throw new ProductException(ex.Message);
                }
                return ProductUpdated;

            }

             bool DeleteProductDAL(int deleteProductID)
            {
                bool productDeleted = false;
                try
                {
                    Product deleteProduct = null;
                    foreach (Product item in ProductList)
                    {
                        if (item.ProductID == deleteProductID)
                        {
                            deleteProduct = item;
                        }
                    }

                    if (deleteProduct != null)
                    {
                        ProductList.Remove(deleteProduct);
                        productDeleted = true;
                    }
                }
                catch (DbException ex)
                {
                    throw new ProductException(ex.Message);
                }
                return productDeleted;




            }

        }
    }
}
