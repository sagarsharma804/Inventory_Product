﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Common;
using System.Threading.Tasks;
using InventoryManagement.Entities;
using InventoryManagement.Exception;


namespace InventoryManagement.DataAccessLayer
{
    public class ProductOrderDAL
    {
         public static List<ProductOrder> ProductOrderList = new List<ProductOrder>();

        public bool AddProductOrderDAL(ProductOrderDAL newProductOrder)
        {
            bool ProductOrderDALAdded = false;
            try
            {
                ProductOrderList.Add(newProductOrder);
                ProductOrderDALAdded = true;
            }
            catch (SystemException ex)
            {
                throw new ProductOrderException(ex.Message);
            }
            return ProductOrderDALAdded;
        }
       

        public List<ProductOrder> GetAllProductOrderDAL() 
        {
            return ProductOrderDAL;
        }
            List<ProductOrder> GetProductOrderByIDDAL(string ProductOrderID)
            {
                List<ProductOrder> SearchProductOrderID = new List<ProductOrder>();
                try
                {
                    foreach (ProductOrderID item in ProductOrderList)
                    {
                        if (item.ProductOrderID == ProductOrderID)
                        {
                            searchProductOrderID.Add(item);
                        }
                    }
                }
                catch (SystemException ex)
                {
                    throw new ProductOrderException(ex.Message);
                }
                return searchProductOrder;
            }

           

            
             




            }

        }
    }
}
