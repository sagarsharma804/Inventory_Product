﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using InventoryManagement.Entities;
using InventoryManagement.Exception;

namespace InventoryManagement.DataAccessLayer
{
     public class ProductOrderDetailsDAL
    {
        public static List<ProductOrderDetails> ProductOrderDetailsList = new List<ProductOrderDetails>();

        public bool AddProductorderDetailsDAL(ProductOrderDetails newProductOrderDetails)
        {
            bool ProductOrderDetailsAdded = false;
            try
            {
                ProductOrderDetailsList.Add(newProductOrderDetails);
                ProductOrderDetailsAdded = true;
            }
            catch (ProductOrderDetailsException ex)
            {
                throw new ProductOrderDetailsException(ex.Message);
            }
            return ProductOrderDetailsAdded;

        }

        public ProductOrderDetails SearchProductOrderDetailDAL(int searchProductID)
        {
            ProductOrderDetails searchProductOrderDetail = null;
            try
            {
                searchProductOrderDetail = ProductOrderDetailsList.Find(item => item.ProductID == searchProductID);
            }
            catch (ProductOrderDetailsException ex)
            {
                throw new ProductOrderDetailsException(ex.Message);
            }
            return searchProductOrderDetails;
        }

        public List<ProductOrderDetails> GetAllProductOrderDetailsDAL()
        {
            return ProductOrderDetailsList;
        }
    }
}
