﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using InventoryManagement.DataAccessLayer;
using InventoryManagement.Entities;

namespace InventoryManagement.BusinessLayer
{
    class ProductOrderDetailsBL
    {

        public int ProductQuantity { get; set; }
        public int ProductPrice { get; set; }
        private double productAmount;
        public double ProductAmount()
        {
            productAmount = ProductPrice * ProductQuantity;
            return productAmount;
        }
        public double CalcAmount(ProductOrderDetails ProductOrderDetails)
        {
            double amount = 0;
            try
            {
                amount = ProductOrderDetails.ProductOrderQuantity * ProductOrderDetails.ProductPrice;
            }
            catch (ProductOrderDetailsException)
            {
                throw;
            }
            return amount;
        }
        private static bool ValidateProductOrderDetails(ProductOrderDetails ProductOrderDetail)
        {
            bool validProductOrderDetails = true;
            try
            {
                StringBuilder sb = new StringBuilder();

                if (ProductOrderDetail.ProductID == 0 || ProductOrderDetail.ProductID > 99999)
                {
                    validProductOrderDetails = false;
                    sb.Append("\nInvalid Raw Material OrderID");
                }
                if (ProductOrderDetail.ProductOrderQuantity <= 0)
                {
                    validProductOrderDetails = false;
                    sb.Append("\nInvalid Quantity");
                }
                if (ProductOrderDetail.ProductPrice <= 0)
                {
                    validProductOrderDetails = false;
                    sb.Append("\nInvalid Unit Price");
                }
                if (validProductOrderDetails == false)
                {
                    throw new ProductOrderDetailsException(sb.ToString());
                }
            }
            catch (ProductOrderDetailsException)
            {
                throw;
            }

            return validProductOrderDetails;
        }

        public static bool AddProductOrderDetailsBL(ProductOrderDetails newProductOrderDetail)
        {
            bool ProductOrderDetailsAdded = false;
            try
            {
                if (ValidateProductOrderDetails(newProductOrderDetail))
                {
                    ProductOrderDetailsDAL ProductDAL = new ProductOrderDetailsDAL();
                    ProductOrderDetailsAdded = ProductDAL.AddProductorderDetailsDAL(newProductOrderDetail);
                }
                else
                {
                    throw new InventoryException("Invalid Order Material Details");
                }
            }
            catch (ProductOrderDetailsException)
            {
                throw;
            }
            return ProductOrderDetailsAdded;
        }
    }
}
