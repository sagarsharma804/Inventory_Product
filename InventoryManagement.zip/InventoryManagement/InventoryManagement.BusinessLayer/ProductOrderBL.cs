﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using InventoryManagement.Entities;
using InventoryManagement.DataAccessLayer;


namespace InventoryManagement.BusinessLayer
{
    class ProductOrderBL
    {
        public double CalcTotalAmount(List<ProductOrderDetails> productOrderDetails)
        {
            double totalAmount = 0;
            try
            {
                foreach (ProductOrderDetails item in productOrderDetails)
                {
                    totalAmount += CalcTotalAmount(productOrderDetails);
                }
            }
            catch (ProductOrderDetailsException)
            {
                throw;
            }
            return totalAmount;
        }
        private static bool ValidateProductOrder(ProductOrder productOrder)
        {
            StringBuilder sb = new StringBuilder();
            bool validProductOrder = true;
            if (productOrder.ProductOrderID == string.Empty)
            {
                validProductOrder = false;
                sb.Append(Environment.NewLine + "Invalid ProductOrder ID");

            }
            
            
            if (validProductOrder == false)
                throw new ProductOrderException(sb.ToString());
            return validProductOrder;
        }
        public static bool AddProductOrderBL(ProductOrder newProductOrder)
        {
            bool ProductOrderAdded = false;
            try
            {
                if (ValidateProductOrder(newProductOrder))
                {
                    ProductOrderBL ProductOrderBL = new ProductOrderBL();
                    ProductOrderAdded = AddProductOrderBL(newProductOrder);
                }
            }
            catch (ProductOrderException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return ProductOrderAdded;
        }
        public static List<ProductOrder> GetAllProductOrderBL()
        {
            List<ProductOrder> ProductOrderList = null;
            try
            {
                ProductOrderDAL productOrderDAL = new ProductOrderDAL();
                ProductOrderList = productOrderDAL.GetAllProductOrderDAL();
            }
            catch (ProductOrderException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return ProductOrderList;
        }
        public static ProductOrder SearchProductOrderBL(int searchProductOrderID)
        {
            ProductOrder searchProductOrder = null;
            try
            {
                ProductOrderDAL ProductOrderDAL = new ProductOrderDAL();
                searchProductOrder = ProductOrderDAL.SearchProductOrder(searchProductOrderID);
            }
            catch (ProductOrderException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchProductOrder;

        }
    }
}
