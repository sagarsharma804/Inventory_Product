﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InventoryManagement.Entities
{
    public class ProductOrder
    {
		public string ProductOrderID { get; set; }
		public DateTime ProductOrderDate { get; set; }
        
    }
}
