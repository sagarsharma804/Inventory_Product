﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InventoryManagement.Entities
{
    class ProductOrder
    {
		public string ProductOrderID { get; set; }
		public string DistributerID { get; set; }
		public DateTime ProductOrderDate { get; set; }
		
    }
}
