﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inventory.Entities
{
    public class Product
    {
      

        public int ProductID {get;set; }
        public string ProductName { get; set; }
        public string ProductType { get; set; }
        //shift it in product order details
        
        //Calculating the amount for all the product of same type.
        

       
    }
}