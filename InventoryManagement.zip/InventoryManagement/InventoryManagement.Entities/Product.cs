﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inventory.Entities
{
    public class Product
    {
        private int productID;

        public int ProductID
        {
            get { return productID; }
            set { productID = value; }
        }
        private string productName;

        public string ProductName
        {
            get { return productName; }
            set { productName = value; }
        }

        private string productType;

        public string ProductType
        {
            get { return productType; }
            set { productType = value; }
        }

        private int productQuantity;
        public int ProductQuantity
        {
            get { return productQuantity; }
            set { productQuantity = value; }
        }

        private int productprice;
        public int Productprice
        {
            get { return productprice; }
            set { productprice = value; }
        }

        private double productAmount;
        public double ProductAmount()
        {
            productAmount = Productprice * ProductQuantity;
            return productAmount;
        }

        public Product()
        {
            productID = 0;
            productName = string.Empty;
            productType = string.Empty;
            productQuantity = 0;
            productprice = 0;

        }
    }
}