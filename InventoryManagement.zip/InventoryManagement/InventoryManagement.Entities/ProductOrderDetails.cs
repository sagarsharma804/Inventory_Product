﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InventoryManagement.Entities
{
    public class ProductOrderDetails
        {

            public int ProductID { get; set; }
            public int ProductOrderQuantity { get; set; }
            public double ProductPrice { get; set; }
        }
  
}
